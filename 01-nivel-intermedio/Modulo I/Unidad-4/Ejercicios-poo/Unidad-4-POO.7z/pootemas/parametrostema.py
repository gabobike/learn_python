bcolor = 'yellow'
bfont  = 'Arial'
bsize  = 12
